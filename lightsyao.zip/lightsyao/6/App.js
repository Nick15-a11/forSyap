import './App.css';
import StudentInfo from './components/StudentInfo';
import Notes from './Notes';



function App() {
  return (
    <div >
  <StudentInfo></StudentInfo>
  <Notes></Notes>
    </div>
  );
}

export default App;
