import './styles.css';
import React, { useState } from "react";
import "react-datepicker/dist/react-datepicker.css";
import DatePicker from "react-datepicker";
import AdditionalInfo from "./StudentInfoHandler";
import PropTypes from 'prop-types';

function StudentInfo() {
    const renderYearOptions = () => {
        const currentYear = new Date().getFullYear();
        const years = [];
        for (let i = currentYear; i >= currentYear - 10; i--) {
            years.push(i);
        }
        return years.map((year) => (
            <option key={year} value={year}>
                {year}
            </option>
        ));
    };

    const [birthdate, setBirthdate] = useState(null);

    const isFormValid = () => {
        return (
            formData.name &&
            formData.email &&
            birthdate &&
            formData.year &&
            formData.faculty &&
            formData.gruppa &&
            formData.specialnost
        );
    };

    const [formData, setFormData] = useState({
        name: "",
        email: "",
        message: "",
        birthdate: "",
        faculty: "",
        gruppa: "",
        specialnost: ""
    });

    const handleChange = (event) => {
        const { name, value } = event.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        setFormData({
            ...formData,
            submitted: true,
            birthdate: birthdate
        });
        setBirthdate(null);
    };

    const handleReset = () => {
        setFormData({
            name: "",
            email: "",
            message: "",
            birthdate: "",
            faculty: "",
            gruppa: "",
            specialnost: "",
            phone: "",
            submitted: false
        });
        setBirthdate(null);
    };

    class TestComponent extends React.Component {
        constructor(props) {
            super(props);
            // Don't call this.setState() here!
            this.state = { name: 'Nick',surname:'Ksyuf',age:20,email:'feuir@gmail.com',phone:'+4380634666' ,symb:'*'};
        }
        render() {
            return (
                <p>
                    {this.props.name}
                    {this.props.surname}
                    {this.props.age}
                    {this.props.email}
                    {this.props.phone}
                    {this.props.symb}
                </p>
            );
        }
    }

    TestComponent.propTypes = {
        sutname: PropTypes.array,
        email: PropTypes.bool,
        age: PropTypes.number,
        object: PropTypes.object,
        name: PropTypes.string,
        symb: PropTypes.string //symbol
    };

    return (
        <div className='my-component'>
          {formData.submitted ? (
            <div className='my-component-qwerty'>
              <table>
                <tr>
                  <td>ФИО:</td>
                  <td>{formData.name}</td>
                </tr>
                <tr>
                  <td>Дата рождения:</td>
                  <td>{formData.birthdate.toLocaleDateString()}</td>
                </tr>
                <tr>
                  <td>Дата поступления:</td>
                  <td>{formData.year}</td>
                </tr>
                <tr>
                  <td>Факультет:</td>
                  <td>{formData.faculty}</td>
                </tr>
                <tr>
                  <td>Группа:</td>
                  <td>{formData.gruppa}</td>
                </tr>
                <tr>
                  <td>Специальность:</td>
                  <td>{formData.specialnost}</td>
                </tr>
                <tr>
                  <td>Email:</td>
                  <td>{formData.email}</td>
                </tr>
                <tr>
                  <td>Номер телефона:</td>
                  <td>{formData.phone}</td>
                </tr>
                <AdditionalInfo formData={formData} />
              </table>
              <button className='my-component-reset-button' onClick={handleReset}>Reset</button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className='my-component-form'>
              <label className='my-component-label'>
                ФИО:
                <input
                  type='text'
                  name='name'
                  value={formData.name}
                  onChange={handleChange}
                  className='my-component-input'
                />
              </label>
              <label className='my-component-label'>
                Дата рождения:
                <DatePicker
                  selected={birthdate}
                  onChange={(date) => setBirthdate(date)}
                  dateFormat='dd/MM/yyyy'
                  showYearDropdown
                  scrollableYearDropdown
                  yearDropdownItemNumber={100}
                  className='my-component-input'
                />
              </label>
              <label className='my-component-label'>
                Дата поступления:
                <select
                  name='year'
                  value={formData.year}
                  onChange={handleChange}
                  className='my-component-input'
                >
                  {renderYearOptions()}
                </select>
              </label>
              <label className='my-component-label'>
                Факультет:
                <input
                  type='text'
                  name='faculty'
                  value={formData.faculty}
                  onChange={handleChange}
                  className='my-component-input'
                />
              </label>
                    <label className='my-component-label'>
                        Группа:
                        <input
                            type="text"
                            name="gruppa"
                            value={formData.gruppa}
                            onChange={handleChange}
                            className='my-component-input'
                        />
                    </label>
                    <label className='my-component-label'>
                        Специальность:
                        <input
                            type="text"
                            name="specialnost"
                            value={formData.specialnost}
                            onChange={handleChange}
                            className='my-component-input'
                        />
                    </label>
                    <label className='my-component-label'>
                        Email:
                        <input
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            className='my-component-input'
                        />
                    </label>
                    <label className='my-component-label'>
                        Номер телефона:
                        <input
                            type="tel"
                            name="phone"
                            value={formData.phone}
                            onChange={handleChange}
                            className='my-component-input'
                        />
                    </label>
                    <input  type="submit" value="Submit" disabled={!isFormValid()} className='my-component-label' />
                </form>
            )}
            <TestComponent></TestComponent>
        </div>
    );
}
export default StudentInfo;
