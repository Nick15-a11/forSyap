import "react-datepicker/dist/react-datepicker.css";

const calculateAge = (birthdate) => {
    const today = new Date();
    const birthDate = new Date(birthdate);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };
  
  const calculateCourse = (year) => {
    const currentYear = new Date().getFullYear();
    const course = currentYear - year;
    return course > 4 ? "Окончил университет" : course;
  };

  const getEmailProvider = (email) => {
    return email.split('@')[1];
  };

  const getMobileProvider = (phoneNumber) => {
    const formattedNumber = phoneNumber.startsWith('+') ? phoneNumber.slice(1) : phoneNumber;
    const operatorCode = formattedNumber.slice(3, 5);

    const operators = {
      '29': 'A1 (Velcom)',
      '33': 'МТС',
      '44': 'A1',
      '25': 'Life',
      '17': 'Городской',
    };

    return operators[operatorCode] || 'Неизвестный оператор';
  };

const AdditionalInfo = ({ formData }) => {
  const age = calculateAge(formData.birthdate);
  const course = calculateCourse(formData.year);
  const emailProvider = getEmailProvider(formData.email);
  const mobileProvider = getMobileProvider(formData.phone);

  return (
    <div>
      <tr>Возраст: {age}</tr>
      <tr>Курс: {course}</tr>
      <tr>Оператор электронной почты: {emailProvider}</tr>
      <tr>Оператор мобильной связи: {mobileProvider}</tr>
    </div>
  );
};

export default AdditionalInfo;