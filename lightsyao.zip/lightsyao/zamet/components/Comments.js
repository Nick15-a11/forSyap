import { useState } from 'react';
import './css/style.css';
import Avatar1 from "./avatars/avatar1.jpg";
import Avatar2 from "./avatars/avatar2.jpg";
import Avatar3 from "./avatars/avatar3.jpg";
import CommentsItem from "./CommentsItem";

const CommentsAdd = ({ onAddComment }) => {
    const [name, setName] = useState('');
    const [avatar, setAvatar] = useState(Avatar1);
    const [email, setEmail] = useState('');
    const [text, setText] = useState('');
    const [secretWord, setSecretWord] = useState('');

    const handleAvatarChange = (event) => {
        setAvatar(event.target.value);
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        const comment = {
            name,
            avatar,
            email,
            text,
            secretWord,
            date: new Date().toLocaleString(),
        };
        onAddComment(comment);
        setName('');
        setAvatar('');
        setEmail('');
        setText('');
        setSecretWord('');
    };

    return (
        <form onSubmit={handleSubmit} className=''>
            <div>
                <label htmlFor="name">Name:</label>
                <input
                    type="text"
                    id="name"
                    value={name}
                    onChange={(event) => setName(event.target.value)}
                />
            </div>
            <div>
                <label htmlFor="avatar">Avatar:</label>
                <select id="avatar" value={avatar} onChange={handleAvatarChange}>
                    <option value={Avatar1}>Avatar 1</option>
                    <option value={Avatar2}>Avatar 2</option>
                    <option value={Avatar3}>Avatar 3</option>
                </select>
                <img src={avatar} alt="avatar" />
            </div>
            <div>
                <label htmlFor="email">Email:</label>
                <input
                    type="email"
                    id="email"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                />
            </div>
            <div>
                <label htmlFor="text">Text:</label>
                <textarea
                    id="text"
                    value={text}
                    onChange={(event) => setText(event.target.value)}
                    className='text'
                />
            </div>
            <div>
                <label htmlFor="secretWord">Secret word:</label>
                <input
                    type="text"
                    id="secretWord"
                    value={secretWord}
                    onChange={(event) => setSecretWord(event.target.value)}
                />
            </div>
            <button type="submit">Add comment</button>
        </form>
    );
};
const Comments = () => {
    const [comments, setComments] = useState([]);
    const [isSecretWordIncorrect,setIsSecretWordIncorrect] = useState(false);

    const handleAddComment = (comment) => {
        setComments([...comments, comment]);
    };

    const handleEditComment = (commentId, newText) => {
        // Найти комментарий по id и изменить его текст
    };

    const handleDeleteComment = (commentId, secretWord) => {
        for(let i = 0;i < comments.length;i++){
            if(comments[i].id === commentId){
                if(comments[i].secretWord === secretWord){
                    const newComments = comments.filter((comment, commentIndex) => commentIndex !== i);
                    setComments(newComments);
                    return true;
                }
            }
            setIsSecretWordIncorrect(true);
            return false;
        }
    };

    const handleShowCommentInfo = (commentId) => {
    };

    const CommentsList = ({ comments, onEditComment, onDeleteComment, onShowCommentInfo }) => {
        return (
            <div>
                {comments.map((comment) => (
                    <CommentsItem
                        key={comment.id}
                        comment={comment}
                        onEditComment={onEditComment}
                        onDeleteComment={onDeleteComment}
                        onShowCommentInfo={onShowCommentInfo}
                    />
                ))}
            </div>
        );
    };
    const CommentsEdit = ({ comment, onEdit, onCancel }) => {
        const [newText, setNewText] = useState(comment.text);

        const handleSubmit = (event) => {
            event.preventDefault();
            onEdit(newText);
        };

        return (
            <form onSubmit={handleSubmit} >
                <div>
                    <label htmlFor="newText">New text:</label>
                    <textarea
                        id="newText"
                        value={newText}
                        onChange={(event) => setNewText(event.target.value)}
                    />
                </div>
                <button type="submit">Save</button>
                <button type="button" onClick={onCancel}>
                    Cancel
                </button>
            </form>
        );
    };

    return (
        <div className='app'>
            <CommentsAdd onAddComment={handleAddComment} />
            <CommentsList
                comments={comments}
                onEditComment={handleEditComment}
                onDeleteComment={handleDeleteComment}
                onShowCommentInfo={handleShowCommentInfo}
            />
        </div>
    );
};

export default Comments;