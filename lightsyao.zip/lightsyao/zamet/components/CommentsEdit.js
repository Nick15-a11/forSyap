import { useState } from 'react';

const CommentsEdit = ({ comment, onEdit, onCancel }) => {
    const [newText, setNewText] = useState(comment.text);

    const handleSubmit = (event) => {
        event.preventDefault();
        onEdit(newText);
    };

    return (
        <form onSubmit={handleSubmit} >
            <div>
                <label htmlFor="newText">New text:</label>
                <textarea
                    id="newText"
                    value={newText}
                    onChange={(event) => setNewText(event.target.value)}
                />
            </div>
            <button type="submit">Save</button>
            <button type="button" onClick={onCancel}>
                Cancel
            </button>
        </form>
    );
};

export default CommentsEdit;