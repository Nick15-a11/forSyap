import { useState } from 'react';

const CommentsDel = ({ onDelete, onCancel,onSecretWordIncorrect }) => {
    const [secretWord, setSecretWord] = useState('');

    const handleSubmit = (event) => {
        event.preventDefault();
        onDelete(secretWord);
    };

    return (
        <form onSubmit={handleSubmit}>
            <div>
                <label htmlFor="secretWord">Secret word:</label>
                <input
                    type="text"
                    id="secretWord"
                    value={secretWord}
                    onChange={(event) => setSecretWord(event.target.value)}
                />
            </div>
            <button type="submit">Delete</button>
            <button type="button" onClick={onCancel}>
                Cancel
            </button>
            {onSecretWordIncorrect && (<p className='incorrect'>Неверно введенный пароль!</p>)}
        </form>
    );
};

export default CommentsDel;