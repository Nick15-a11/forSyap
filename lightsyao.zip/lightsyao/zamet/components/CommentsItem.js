import { useState } from 'react';
import CommentsEdit from './CommentsEdit';
import CommentsDel from './CommentsDel';
import './css/style.css';

const CommentsInfo =({ name, email, date, onClose }) => {
    return (
        <div>
            <p>Name: {name}</p>
            <p>Email: {email}</p>
            <p>Date: {date}</p>
            <button onClick={onClose}>Close</button>
        </div>
    );
};

const CommentsItem = ({ comment, onEditComment, onDeleteComment, onShowCommentInfo }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);
    const [isShowingInfo, setIsShowingInfo] = useState(false);

    const handleEdit = (newText) => {
        onEditComment(comment.id, newText);
        setIsEditing(false);
    };

    const handleDelete = (secretWord) => {
        let isDeleted = onDeleteComment(comment.id, secretWord);
        if(isDeleted){
            setIsDeleting(false);
        }

    };

    const handleShowInfo = () => {
        setIsShowingInfo(true);
    };

    return (
        <div>
            <div className='comment'>
                <img src={comment.avatar} alt="avatar" />
                <h3>{comment.name}</h3>
                <p className='text'>{comment.text}</p>
                <button onClick={() => setIsEditing(true)}>Edit</button>
                <button onClick={() => setIsDeleting(true)}>Delete</button>
                <button onClick={handleShowInfo}>Info</button>
            </div>
            {isEditing && (
                <CommentsEdit
                    comment={comment}
                    onEdit={handleEdit}
                    onCancel={() => setIsEditing(false)}
                />
            )}
            {isDeleting && <CommentsDel onSecretWordIncorrect={true} onDelete={handleDelete} onCancel={() => setIsDeleting(false)} />}
            {isShowingInfo && (
                <CommentsInfo
                    name={comment.name}
                    email={comment.email}
                    date={comment.date}
                    onClose={() => setIsShowingInfo(false)}
                />
            )}
        </div>
    );
};

export default CommentsItem;