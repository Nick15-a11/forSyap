import React, { useState } from 'react';

const GenderSelector = () => {
  const [selectedGender, setSelectedGender] = useState('');

  const handleGenderChange = (e) => {
    setSelectedGender(e.target.value);
  };

  return (
    <div >
      <label
      className='male'>
        <input
          type="radio"
          value="male"
          checked={selectedGender === 'male'}
          onChange={handleGenderChange}
        />
        Мужской
      </label>
      <label
      className='male'>
        <input
          type="radio"
          value="female"
          checked={selectedGender === 'female'}
          onChange={handleGenderChange}
        />
        Женский
      </label>
        
    </div>
  );
};

export default GenderSelector;