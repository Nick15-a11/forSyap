import React, {useMemo, useState, useEffect, useCallback} from 'react';
import moment from 'moment';
import {
    CalendarWrapper,
    CalendarContainer,
    PagingButton,
    Day,
    DayHeader,
    HeaderPosition,
    BorderCalendar
} from './CalendarComponents';
import './resources/note.css';
import './resources/calendar.css';


function Scheduler() {

    const [calendarState, setCalendarState] = useState(moment());
    const [isActiveDays, setValue] = useState([]);
    const [reload, setReload] = useState();
    const [shownote, setShowNote] = useState(false);
    const [daynotes, addDayNote] = useState(new Map());
    const [title, setTitle] = useState('');
    const [text, setText] = useState('');
    const [noteDayId, setNoteDayId] = useState('')

    const addNote = (noteDayId, note) => {
        let selectedDayNotes = daynotes.get(noteDayId);
        if (selectedDayNotes) {
            selectedDayNotes.push(note);
        } else {
            selectedDayNotes = [note];
        }
        addDayNote(daynotes.set(noteDayId, selectedDayNotes));
    }

    const updateDayNotes = (noteDayId, notes) => {
        let updatedNotes = daynotes.set(noteDayId, notes);
        console.log(updatedNotes);
        addDayNote(updatedNotes);
    }


    useEffect(() => {
        // код не нужен,используется для ререндера данных
    }, [reload]);

    const getClassName = (day_id) => {
        if (daynotes.get(day_id) && daynotes.get(day_id).length > 0) {
            return 'notes';
        }
        if (day_id !== noteDayId) {
            return 'notselected';
        }
        return isActiveDays.indexOf(day_id) > -1 ? 'selected' : 'notselected';
    }

    const createDaysOfMonth = () => {
        const date = moment(calendarState).endOf('month');
        const lastDate = date.date();
        const firstWeekday = date.startOf('month').day();
        const calendarDays = [];
        const today = moment();

        let month_num = moment(calendarState).month();

        for (let w = 0; w < firstWeekday; w++) {
            calendarDays.push(<Day key={Math.random()}/>); // empty days
        }

        for (let day_num = 1; day_num <= lastDate; day_num++) {
            let day_id = month_num + '_' + day_num;
            calendarDays.push(<Day key={day_num} today={date.date(day_num).isSame(today, 'day')} id={day_id}
                                   onClick={() => handleDayClick(day_id)}
                                   className={getClassName(day_id)}>{day_num}</Day>);
        }

        while (calendarDays.length % 7 !== 0) {
            calendarDays.push(<Day key={Math.random()}/>);
        }

        return calendarDays;
    }

    const handleDayClick = useCallback((day_id) => {
        const index = isActiveDays.indexOf(day_id);
        if (index > -1 && !shownote) {
            setShowNote(true);
            setTitle('');
            setText('');
        } else {
            setValue([]);
            setTitle('');
            setText('');
            setShowNote(false);
            isActiveDays.push(day_id);
        }
        setNoteDayId(day_id);
        setValue(isActiveDays);
        setReload(!reload);
    }, [isActiveDays, reload, shownote]);


    const prevMonth = useCallback(() =>
            setCalendarState(moment(calendarState).subtract(1, 'month'))
        , [setCalendarState, calendarState]);

    const nextMonth = useCallback(() =>
            setCalendarState(moment(calendarState).add(1, 'month'))
        , [setCalendarState, calendarState]);

    const formattedTime = useMemo(() =>
            moment(calendarState).format('MMMM YYYY')
        , [calendarState])

    const handleTitleChange = (event) => {
        setTitle(event.target.value);
    };

    const handleTextChange = (event) => {
        setText(event.target.value);
    };

    const handleRemoveAllNotes = () => {
        updateDayNotes(noteDayId, []);
        setShowNote(false);
        setReload(!reload);
    };

    const handleRemoveNote = (index) => {
        const newNotes = daynotes.get(noteDayId).filter((note, noteIndex) => noteIndex !== index);
        console.log(newNotes);
        updateDayNotes(noteDayId, newNotes);
        if (newNotes.length === 0) {
            setShowNote(false);
        }
        setReload(!reload)
    };

    const collectDayNote = (event) => {
        event.preventDefault();
        let newNote = {'title': title, 'text': text};
        addNote(noteDayId, newNote)
        setTitle('');
        setText('');
    };

    return (<div><CalendarWrapper>
        <BorderCalendar>
            <HeaderPosition>
                <PagingButton onClick={prevMonth}>&lt;</PagingButton>
                <h2>{formattedTime}</h2>
                <PagingButton onClick={nextMonth}>&gt;</PagingButton>
            </HeaderPosition>
            <CalendarContainer>
                <DayHeader>Sunday</DayHeader>
                <DayHeader>Monday</DayHeader>
                <DayHeader>Tuesday</DayHeader>
                <DayHeader>Wednesday</DayHeader>
                <DayHeader>Thursday</DayHeader>
                <DayHeader>Friday</DayHeader>
                <DayHeader>Saturday</DayHeader>
                {createDaysOfMonth()}
            </CalendarContainer>
        </BorderCalendar>

    </CalendarWrapper>

        {shownote && (<div className="notes-container">
            <form className="form-container" onSubmit={collectDayNote}>
                <label>
                    Заголовок заметки:
                    <input type="text" value={title} onChange={handleTitleChange}/>
                </label>
                <label>
                    Текст заметки:
                    <textarea value={text} onChange={handleTextChange}/>
                </label>
                <button type="submit">Добавить заметку</button>
            </form>
            <hr/>
            <h2>Заметки:</h2>
            {daynotes.get(noteDayId) && daynotes.get(noteDayId).map((note, index) => (
                <div className="note-wrapper" key={index}>
                    <h3>{note.title}</h3>
                    <p>{note.text}</p>
                    <button onClick={() => handleRemoveNote(index)}>Удалить заметку</button>
                </div>
            ))}
            {daynotes.get(noteDayId) && daynotes.get(noteDayId).length > 2 && (<div>
                    <div className="button-wrapper">
                        <button onClick={() => handleRemoveAllNotes()}>Удалить все заметки</button>
                    </div>
                </div>
            )}
        </div>)}
    </div>)
}

export default Scheduler;