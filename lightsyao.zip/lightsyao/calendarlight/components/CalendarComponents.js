import styled from 'styled-components';
export const CalendarWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`;

export const CalendarContainer = styled.div`
	width: 100%;
	max-width: 800px;
	display: flex;
	flex-wrap: wrap;
    padding-top: 40px;
`;
export const PagingButton = styled.button`
  display: inline-flex;
  background-color: #4b4142;
  color: #ffffff;
  font-size: 24px;
  height: 25px;
  border: none;
  border-radius: 12px;
  margin: 22px;
  cursor: pointer;

  &:hover {
    background-color: #4b4142;
  }
`;
export const Day = styled.div`
  box-sizing: border-box;
  font-size: 20px;
  width: ${ 100 / 7 }%;
  padding: 4px;
  color: ${props => props.today ? '#fefffe' : '#000000'};
  border: 1px solid;
  border-color: ${props => props.today ? '#171ca9' : ''};
  height: 50px;
`;
export const DayHeader = styled(Day)`
  text-align: center;
  font-size: 16px;
  padding-top: 8px;
  height: 40px;
  color: #f6f5f5;
  background-color: #4b4142;
`;
export const HeaderPosition = styled.div`
  display:flex;
  align-items: center;
`;
export const BorderCalendar = styled.div`
  border: 1px black solid;
`;
