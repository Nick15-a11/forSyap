import React, {useMemo, useState, useEffect, useCallback} from 'react';
import moment from 'moment';
import {
    CalendarWrapper,
    CalendarContainer,
    PagingButton,
    Day,
    DayHeader,
    HeaderPosition,
    BorderCalendar
} from './CalendarComponents';


function Calendar() {

    const [calendarState, setCalendarState] = useState(moment());
    const [isActiveDays, setValue] = useState([]);
    const [reload, setReload] = useState();

    useEffect(() => {
        // код не нужен,только для выбранных/невыбранных дней
    }, [reload]);

    const createDaysOfMonth = () => {

        const date = moment(calendarState).endOf('month');
        const lastDate = date.date();
        const firstWeekday = date.startOf('month').day();
        const calendarDays = [];
        const today = moment();

        let month_num = moment(calendarState).month();

        for (let w = 0; w < firstWeekday; w++) {
            calendarDays.push(<Day key={Math.random()}/>); // empty days
        }

        for (let day_num = 1; day_num <= lastDate; day_num++) {
            let day_id = month_num + '_' + day_num;
            calendarDays.push(<Day key={day_num} today={date.date(day_num).isSame(today, 'day')} id={day_id}
            onClick={() => handleDayClick(day_id)}
            className={isActiveDays.indexOf(day_id) > -1 ? 'selected' : 'notselected'}>{day_num}</Day>);
        }

        while (calendarDays.length % 7 !== 0) {
            calendarDays.push(<Day key={Math.random()}/>);
        }

        return calendarDays;
    }

    const handleDayClick = useCallback((day_id) => {
        const index = isActiveDays.indexOf(day_id);
        console.log(index);
        if (index > -1) {
            isActiveDays.splice(index, 1);
        } else {
            isActiveDays.push(day_id)
        }
        setValue(isActiveDays)
        setReload(!reload)
    }, [isActiveDays, reload]);

    const prevMonth = useCallback(() =>
            setCalendarState(moment(calendarState).subtract(1, 'month'))
        , [setCalendarState, calendarState])

    const nextMonth = useCallback(() =>
            setCalendarState(moment(calendarState).add(1, 'month'))
        , [setCalendarState, calendarState])

    const formattedTime = useMemo(() =>
            moment(calendarState).format('MMMM YYYY')
        , [calendarState])


    return <CalendarWrapper>
        <BorderCalendar>
            <HeaderPosition>
                <PagingButton onClick={prevMonth}>&lt;</PagingButton>
                <h2>{formattedTime}</h2>
                <PagingButton onClick={nextMonth}>&gt;</PagingButton>
            </HeaderPosition>
            <CalendarContainer>
                <DayHeader>Sunday</DayHeader>
                <DayHeader>Monday</DayHeader>
                <DayHeader>Tuesday</DayHeader>
                <DayHeader>Wednesday</DayHeader>
                <DayHeader>Thursday</DayHeader>
                <DayHeader>Friday</DayHeader>
                <DayHeader>Saturday</DayHeader>
                {createDaysOfMonth()}
            </CalendarContainer>
        </BorderCalendar>
    </CalendarWrapper>;
}

export default Calendar;