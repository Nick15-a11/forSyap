import React, {useState, useMemo} from 'react'
import './resources/css/phone_input.css'
import ReactFlagsSelect from "react-flags-select";


export default function Phone() {

    const [inpValue, setInputValue] = useState("");
    const [select, setSelect] = useState("");
    const [countryFlag, setCountryFlag] = useState("");

    const countryData = new Map();
    countryData.set("BY",
        {
            code: "375",
            countryFlag: "flagsBY",
            operators: ["A1", "life:)", "MTC"],
            searchValue: /(\d{3})(\d{2})(\d{3})(\d{2})(\d{2})/g,
            replaceValue: '+$1 ($2) $3-$4-$5'
        })
    countryData.set("RU",
        {
            code: "7",
            countryFlag: "flagsRU",
            operators: ["Билайн", "Мегафон", "RU MTC", "RU Tele2"],
            searchValue: /(\d{1})(\d{3})(\d{3})(\d{2})(\d{2})/g,
            replaceValue: '+$1 ($2) $3-$4-$5'
        })
    countryData.set("LT",
        {
            code: "371",
            countryFlag: "flagsLT",
            operators: ["Telia", "LT Bite", "LT Tele2"],
            searchValue: /(\d{3})(\d{4})(\d{4})/g,
            replaceValue: '+$1 $2-$3'
        })
    countryData.set("LV",
        {
            code: "370",
            countryFlag: "flagsLV",
            operators: ["LMT", "LV Tele2", "LV Bite"],
            searchValue: /(\d{3})(\d{2})(\d{3})(\d{2})(\d{2})/g,
            replaceValue: '+$1 ($2) $3-$4-$5'
        })
    countryData.set("UA",
        {
            code: "380",
            countryFlag: "flagsUA",
            operators: ["Lifecell", "Vodafone", "Київстар"],
            searchValue: /(\d{3})(\d{2})(\d{3})(\d{2})(\d{2})/g,
            replaceValue: '+$1 ($2) $3-$4-$5'
        })
    countryData.set("PL",
        {
            code: "48",
            countryFlag: "flagsPL",
            operators: ["Orange", "Play", "Plus", "T-mobile"],
            searchValue: /(\d{2})(\d{3})(\d{3})(\d{3})/g,
            replaceValue: '+$1 $2-$3-$4'
        })

    const operators = new Map();
    operators.set("A1", {code:"44", regex:/\d{2}/i});
    operators.set("life:)", {code:"25", regex:/\d{2}/i});
    operators.set("MTC", {code:"29", regex:/\d{2}/i});
    operators.set("RU MTC", {code:"029", regex:/\d{2}/i});
    operators.set("Билайн", {code:"021", regex:/\d{3}/i});
    operators.set("Мегафон", {code:"022", regex:/\d{3}/i});
    operators.set("RU Tele2", {code:"024", regex:/\d{3}/i});
    operators.set("Telia", {code:"270", regex:/\d{3}/i});
    operators.set("LT Bite", {code:"271", regex:/\d{3}/i});
    operators.set("LT Tele2", {code:"272", regex:/\d{3}/i});
    operators.set("LMT", {code:"27", regex:/\d{2}/i});
    operators.set("LV Bite", {code:"28", regex:/\d{2}/i});
    operators.set("LV Tele2", {code:"29", regex:/\d{2}/i});
    operators.set("Lifecell", {code:"37", regex:/\d{2}/i});
    operators.set("Vodafone", {code:"38", regex:/\d{2}/i});
    operators.set("Київстар", {code:"39", regex:/\d{2}/i});
    operators.set("Orange", {code:"46", regex:/\d{2}/i});
    operators.set("Play", {code:"47", regex:/\d{2}/i});
    operators.set("Plus", {code:"48", regex:/\d{2}/i});
    operators.set("T-mobile", {code:"49", regex:/\d{2}/i});

    const countryCodes = new Map();
    countryCodes.set("+375", "BY")
    countryCodes.set("+7", "RU")
    countryCodes.set("+371", "LT")
    countryCodes.set("+370", "LV")
    countryCodes.set("+380", "UA")
    countryCodes.set("+48", "PL")

    const onSelect = (code) => {
        setSelect(code);
        setInputValue(countryData.get(code).code);
        setCountryFlag(countryData.get(code).countryFlag);
    }

    const addOperator = (operator, select) => {
        let chosenCountryData = countryData.get(select);
        let chosenOperator = operators.get(operator) ? operators.get(operator) : '';
        let inpValueClean = inpValue.replaceAll(/[\(,\), ,\-,\+]/g, '')
        console.log("kolya" + inpValueClean)
        let inpValueWithOperator = '';
        if (inpValueClean === chosenCountryData.code) {
            inpValueWithOperator = inpValueClean + chosenOperator.code
        } else {
            inpValueClean = inpValueClean.replace(chosenCountryData.code, '')
            inpValueWithOperator = chosenCountryData.code + inpValueClean.replace(chosenOperator.regex, chosenOperator.code)
        }
        console.log("ksyuf: " + inpValueWithOperator)
        console.log(inpValueWithOperator.replace(chosenCountryData.searchValue, chosenCountryData.replaceValue))
        setInputValue(inpValueWithOperator.replace(chosenCountryData.searchValue, chosenCountryData.replaceValue));
    }

    const supportedOperators = useMemo(() => {
        let options = [];
        options.push(<option key={"default"}>{"Operator"}</option>);
        if (select === "") {
            return options;
        }
        for (let i = 0; i < countryData.get(select).operators.length; i++) // создать цикл для просмотра Content Lish
        {
            options.push(<option
                key={countryData.get(select).operators[i]}>{countryData.get(select).operators[i]}</option>);
        }
        return options;
    }, [select, countryData])

    const convertPhoneNumber = (inpValue, select) => {
        let inpValueWithoutPlus = inpValue.replaceAll(" ", "+");
        if (select) {
            let chosenCountryData = countryData.get(select);
            if (inpValueWithoutPlus.startsWith(chosenCountryData.code)) {
                inpValueWithoutPlus = inpValueWithoutPlus.replaceAll(/[\(,\), ,\-,\+]/g, '')
                console.log(inpValueWithoutPlus)
                return inpValueWithoutPlus.replace(chosenCountryData.searchValue, chosenCountryData.replaceValue);
            }
        }
        if (countryCodes.get(inpValueWithoutPlus)) {
            setSelect(countryCodes.get(inpValueWithoutPlus));
            setInputValue("+" + inpValueWithoutPlus);
            setCountryFlag(countryData.get(countryCodes.get(inpValueWithoutPlus)).countryFlag);
        }
        return inpValue;
    }

    return (
        <div className='mainclass'>
            <ReactFlagsSelect
                selected={select}
                onSelect={onSelect}
                countries={["BY", "RU", "UA", "PL", "LV", "LT"]}
            />
            <input
                className={countryFlag}
                type="tel"
                list="select_country"
                placeholder="Введите номер"
                onChange={(e) => {
                    setInputValue(e.target.value)
                }}
                value={convertPhoneNumber(inpValue, select)}
            />
            <select onChange={(e) => addOperator(e.target.value, select)} className="operatorsSelect">
                {supportedOperators}
            </select>
        </div>
    )
}
